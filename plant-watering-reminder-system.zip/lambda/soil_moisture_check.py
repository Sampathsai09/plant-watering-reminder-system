import boto3

def lambda_handler(event, context):
    moisture = event.get('moisture', 100)

    if moisture < 30:
        sns = boto3.client('sns')
        sns.publish(
            TopicArn='YOUR_SNS_TOPIC_ARN',
            Message='Alert! Your plant needs watering 🌱💧',
            Subject='Plant Water Alert'
        )

    return {
        'statusCode': 200,
        'body': 'Soil moisture checked'
    }
