# 🌱 Plant Watering Reminder System

An IoT-based cloud project using AWS IoT Core, AWS Lambda, and Amazon SNS
to send email alerts when plants need watering.
